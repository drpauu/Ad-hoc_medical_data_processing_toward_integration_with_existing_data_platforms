{
    "test": [
      {
        "id": 1,
        "name": "John Doe",
        "data": {
          "hr": 80,
          "spo2": 98
        }
      }
    ]
  }
  